export class AddTemplate {
    title : string;
    body : string;
    project: number
}