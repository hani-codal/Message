export class AddTemplate {
    names : string;
    discription : string;
}