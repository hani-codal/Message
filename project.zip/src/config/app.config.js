module.exports = function config() {
  var config = require('./app.config.params.js');
  return config;
}
